details = {
    "searchcomponentid": "",
    "name": "Search Results for Consulations",
    "icon": "",
    "modulename": "",
    "classname": "",
    "type": "results-list",
    "componentpath": "views/components/search/search-results-consultations",
    "componentname": "search-results-consultations",
    "sortorder": "0",
    "enabled": True
}